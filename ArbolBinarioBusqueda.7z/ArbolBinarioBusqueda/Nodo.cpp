#include "Nodo.h"

Nodo::Nodo(int _dato)
{
	dato = _dato;
	izq = NULL;
	der = NULL;
}